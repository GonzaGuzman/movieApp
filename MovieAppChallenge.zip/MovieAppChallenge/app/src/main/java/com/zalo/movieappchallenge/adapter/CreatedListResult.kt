package com.zalo.movieappchallenge.adapter


import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CreatedListResult {}
   /* class CreatedListsResult {
        @SerializedName("id")
        @Expose
        val id: Long? = null

        @SerializedName("title")
        @Expose
        val title: String? = null

        @SerializedName("overview")
        @Expose
        val overview: String? = null

        @SerializedName("poster_path")
        @Expose
        val posterPath: Any? = null

        @SerializedName("backdrop_path")
        @Expose
        val backdropPath: Any? = null

        @SerializedName("vote_average")
        @Expose
        val rating: Float? = null

        @SerializedName("release_date")
        @Expose
        val releaseDate: String? = null

        override fun toString(): String {
            return "CreatedListsResult(id=$id," +
                    " title=$title," + "overView =$overview," +
                    " poster_path=$posterPath," +
                    " backdrop_path=$backdropPath, " +
                    "vote_average=$rating, " +
                    "release_date=$releaseDate)\n\n"
        }
    }
}
*/