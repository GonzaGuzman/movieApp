package com.zalo.movieappchallenge.search.searchPresenter

import android.content.Intent

interface SearchPresenterActions {
    fun searchMovies(intent: Intent)
}